<ul class="nav flex-column">
    <li class="nav-item">
        <a href="{{ route('dashboard') }}" class="nav-link">Dashboard</a>
    </li>
    <li class="nav-item">
        <a href="{{ route('admin.seleksi.index') }}" class="nav-link">Seleksi</a>
    </li>
    <li class="nav-item">
        <a href="{{ route('profile.edit') }}" class="nav-link">Profil</a>
    </li>
</ul>
