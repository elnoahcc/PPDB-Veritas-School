<ul class="nav flex-column">
    <li class="nav-item">
        <a href="{{ route('dashboard') }}" class="nav-link">Dashboard</a>
    </li>
    <li class="nav-item">
        <a href="{{ route('pendaftar.berkas.index') }}" class="nav-link">Berkas Saya</a>
    </li>
    <li class="nav-item">
        <a href="{{ route('profile.edit') }}" class="nav-link">Profil</a>
    </li>
</ul>
